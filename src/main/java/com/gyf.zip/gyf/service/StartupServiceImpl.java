package com.gyf.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gyf.dto.StartupRequest;
import com.gyf.entity.Investor;
import com.gyf.entity.Startup;
import com.gyf.repository.InvestorRepository;
import com.gyf.repository.StartupRepository;

@Service
public class StartupServiceImpl
        implements StartupService {

    @Autowired
    private StartupRepository startupRepository;

    @Autowired
    private InvestorRepository investorRepository;

    @Autowired
    private NotificationService notificationService;

    @Override
    public Startup createStartup(
            StartupRequest request) {

        Startup startup = new Startup();

        startup.setStartupName(
                request.getStartupName());

        startup.setFounderName(
                request.getFounderName());

        startup.setIndustry(
                request.getIndustry());

        startup.setDescription(
                request.getDescription());

        startup.setWebsite(
                request.getWebsite());

        startup.setLocation(
                request.getLocation());

        startup.setValuation(
                request.getValuation());

        startup.setFundingRequired(
                request.getFundingRequired());

        String createdBy =
                request.getCreatedBy();

        if (createdBy == null ||
                createdBy.trim().isEmpty()) {

            createdBy =
                    request.getFounderName();
        }

        startup.setCreatedBy(createdBy);

        startup.setStatus("PENDING");

        Startup saved =
                startupRepository.save(startup);

        notificationService.notifyAdmins(
                "Startup Approval Required",
                saved.getStartupName()
                        + " has been submitted for approval.",
                "STARTUP_APPROVAL",
                saved.getId(),
                "/admin/startups");

        return saved;
    }

    @Override
    public List<Startup> getAllStartups() {

        return startupRepository.findAll();
    }

    @Override
    public Startup approveStartup(Long id) {

        Startup startup =
                startupRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Startup Not Found"));

        startup.setStatus("APPROVED");

        Startup saved =
                startupRepository.save(startup);

        String owner =
                saved.getCreatedBy();

        if (owner == null ||
                owner.trim().isEmpty()) {

            owner = saved.getFounderName();
        }

        notificationService.notifyUserByIdentity(
                owner,
                "Startup Approved",
                "Your startup \""
                        + saved.getStartupName()
                        + "\" has been approved.",
                "STARTUP_APPROVED",
                saved.getId(),
                "/startups");

        notifyMatchingInvestors(saved);

        return saved;
    }

    @Override
    public Startup rejectStartup(Long id) {

        Startup startup =
                startupRepository.findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Startup Not Found"));

        startup.setStatus("REJECTED");

        Startup saved =
                startupRepository.save(startup);

        String owner =
                saved.getCreatedBy();

        if (owner == null ||
                owner.trim().isEmpty()) {

            owner = saved.getFounderName();
        }

        notificationService.notifyUserByIdentity(
                owner,
                "Startup Rejected",
                "Your startup \""
                        + saved.getStartupName()
                        + "\" was rejected.",
                "STARTUP_REJECTED",
                saved.getId(),
                "/startups");

        return saved;
    }

    private void notifyMatchingInvestors(
            Startup startup) {

        List<Investor> investors =
                investorRepository
                        .findByStatusIgnoreCase("APPROVED");

        for (Investor investor : investors) {

            String preferred =
                    investor.getPreferredIndustry();

            if (preferred == null ||
                    preferred.trim().isEmpty() ||
                    preferred.equalsIgnoreCase("ALL") ||
                    preferred.equalsIgnoreCase(
                            startup.getIndustry())) {

                notificationService.notifyUserByIdentity(
                        investor.getEmail(),
                        "Startup Matched",
                        "A startup matching your investment preferences is now available: "
                                + startup.getStartupName(),
                        "STARTUP_MATCHED",
                        startup.getId(),
                        "/startups/"
                                + startup.getId());
            }
        }
    }

    @Override
    public Startup getStartupById(Long id) {

        return startupRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Startup Not Found"));
    }
}