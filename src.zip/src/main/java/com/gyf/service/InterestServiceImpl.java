package com.gyf.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gyf.dto.InterestRequest;
import com.gyf.entity.InvestmentInterest;
import com.gyf.repository.InvestmentInterestRepository;

@Service
public class InterestServiceImpl
        implements InterestService {

    @Autowired
    private InvestmentInterestRepository repository;

    @Override
    public InvestmentInterest createInterest(
            InterestRequest request) {

        InvestmentInterest interest =
                new InvestmentInterest();

        interest.setStartupId(
                request.getStartupId());

        interest.setInvestorId(
                request.getInvestorId());

        interest.setStatus("PENDING");

        return repository.save(interest);
    }

    @Override
    public List<InvestmentInterest> getAllInterests() {
        return repository.findAll();
    }

    @Override
    public InvestmentInterest acceptInterest(
            Long id) {

        InvestmentInterest interest =
                repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Interest Not Found"));

        interest.setStatus("ACCEPTED");

        return repository.save(interest);
    }

    @Override
    public InvestmentInterest rejectInterest(
            Long id) {

        InvestmentInterest interest =
                repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Interest Not Found"));

        interest.setStatus("REJECTED");

        return repository.save(interest);
    }
}