package com.gyf.service;

import java.util.List;

import com.gyf.dto.StartupRequest;
import com.gyf.entity.Startup;

public interface StartupService {

    Startup createStartup(StartupRequest request);

    List<Startup> getAllStartups();
    Startup getStartupById(Long id);
    
    //Approval & Rejection
    Startup approveStartup(Long id);

    Startup rejectStartup(Long id);

}