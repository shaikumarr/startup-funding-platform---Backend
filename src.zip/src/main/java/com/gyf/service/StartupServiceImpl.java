package com.gyf.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gyf.dto.StartupRequest;
import com.gyf.entity.Startup;
import com.gyf.repository.StartupRepository;

@Service
public class StartupServiceImpl implements StartupService {

    @Autowired
    private StartupRepository startupRepository;

    @Override
    public Startup createStartup(StartupRequest request) {

        Startup startup = new Startup();

        startup.setStartupName(request.getStartupName());
        startup.setFounderName(request.getFounderName());
        startup.setIndustry(request.getIndustry());
        startup.setDescription(request.getDescription());
        startup.setWebsite(request.getWebsite());
        startup.setLocation(request.getLocation());
        startup.setValuation(request.getValuation());
        startup.setFundingRequired(request.getFundingRequired());

        startup.setStatus("PENDING");

        return startupRepository.save(startup);
    }

    @Override
    public List<Startup> getAllStartups() {

        return startupRepository.findAll();
    }
    
    //Approval Method
    @Override
    public Startup approveStartup(Long id) {

        Startup startup = startupRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Startup Not Found"));

        startup.setStatus("APPROVED");

        return startupRepository.save(startup);
    }
    
    //Rejection Method
    @Override
    public Startup rejectStartup(Long id) {

        Startup startup = startupRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Startup Not Found"));

        startup.setStatus("REJECTED");

        return startupRepository.save(startup);
    }
    @Override
    public Startup getStartupById(Long id) {

        return startupRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Startup Not Found"));
    }
}