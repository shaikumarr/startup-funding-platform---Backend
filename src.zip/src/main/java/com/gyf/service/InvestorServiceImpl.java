package com.gyf.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gyf.dto.InvestorRequest;
import com.gyf.entity.Investor;
import com.gyf.repository.InvestorRepository;

@Service
public class InvestorServiceImpl implements InvestorService {

    @Autowired
    private InvestorRepository investorRepository;

    @Override
    public Investor createInvestor(InvestorRequest request) {

        Investor investor = new Investor();

        investor.setInvestorName(request.getInvestorName());
        investor.setCompanyName(request.getCompanyName());
        investor.setEmail(request.getEmail());
        investor.setMobile(request.getMobile());
        investor.setInvestmentRange(request.getInvestmentRange());
        investor.setPreferredIndustry(request.getPreferredIndustry());
        investor.setStatus("PENDING");

        return investorRepository.save(investor);
    }
    
    @Override
    public Investor approveInvestor(Long id) {

        Investor investor = investorRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Investor Not Found"));

        investor.setStatus("APPROVED");

        return investorRepository.save(investor);
    }
    
    @Override
    public Investor rejectInvestor(Long id) {

        Investor investor = investorRepository
                .findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Investor Not Found"));

        investor.setStatus("REJECTED");

        return investorRepository.save(investor);
    }
    
    @Override
    public Investor getInvestorById(Long id) {

        return investorRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Investor Not Found"));
    }
    @Override
    public List<Investor> getAllInvestors() {
        return investorRepository.findAll();
    }
}