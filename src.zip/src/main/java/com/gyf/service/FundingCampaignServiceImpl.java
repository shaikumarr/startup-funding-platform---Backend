package com.gyf.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gyf.dto.FundingCampaignRequest;
import com.gyf.entity.FundingCampaign;
import com.gyf.repository.FundingCampaignRepository;

@Service
public class FundingCampaignServiceImpl
        implements FundingCampaignService {

    @Autowired
    private FundingCampaignRepository repository;

    @Override
    public FundingCampaign createCampaign(
            FundingCampaignRequest request) {

        FundingCampaign campaign =
                new FundingCampaign();

        campaign.setStartupId(
                request.getStartupId());

        campaign.setCampaignTitle(
                request.getCampaignTitle());

        campaign.setTargetAmount(
                request.getTargetAmount());

        campaign.setRaisedAmount(0.0);

        campaign.setStatus("ACTIVE");

        return repository.save(campaign);
    }
    
    @Override
    public FundingCampaign getCampaignById(
            Long id) {

        return repository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Campaign Not Found"));
    }
    
    @Override
    public List<FundingCampaign> getAllCampaigns() {

        return repository.findAll();
    }
}