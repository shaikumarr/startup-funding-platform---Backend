package com.gyf.service;

import java.util.List;

import com.gyf.dto.LoginRequest;
import com.gyf.dto.UserRequest;
import com.gyf.entity.User;

public interface UserService {
	
	//Registering user method
    User register(UserRequest request);
    List<User> getAllUsers();
    
  //User Login method
    User login(LoginRequest request);
    
    
  //getting user ByID method
    User getUserById(Long id);
    
    //Delete user 
    void deleteUser(Long id);
    
    //Updating User
    User updateUser(Long id, UserRequest request);

}