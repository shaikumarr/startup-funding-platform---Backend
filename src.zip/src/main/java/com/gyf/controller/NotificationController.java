package com.gyf.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gyf.dto.NotificationResponse;
import com.gyf.entity.Notification;
import com.gyf.repository.InvestorRepository;
import com.gyf.repository.NotificationRepository;
import com.gyf.repository.StartupRepository;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    @Autowired
    private StartupRepository startupRepository;

    @Autowired
    private InvestorRepository investorRepository;

    @Autowired
    private NotificationRepository notificationRepository;

    @GetMapping("/{userId}")
    public List<Notification> getNotifications(
            @PathVariable Long userId) {

        return notificationRepository
                .findByUserIdOrderByCreatedDateDesc(userId);
    }

    @PutMapping("/read/{id}")
    public Notification markRead(
            @PathVariable Long id) {

        Notification notification =
                notificationRepository
                        .findById(id)
                        .orElseThrow(() ->
                                new RuntimeException(
                                        "Notification not found"));

        notification.setIsRead(true);

        return notificationRepository.save(notification);
    }

    @GetMapping
    public List<NotificationResponse> getDashboardNotifications() {

        List<NotificationResponse> list =
                new ArrayList<>();

        long pendingStartups =
                startupRepository
                        .countByStatus("PENDING");

        long pendingInvestors =
                investorRepository
                        .countByStatus("PENDING");

        list.add(
                new NotificationResponse(
                        "Startup Approval",
                        pendingStartups
                                + " startups are waiting for approval"));

        list.add(
                new NotificationResponse(
                        "Investor Approval",
                        pendingInvestors
                                + " investors are waiting for approval"));

        return list;
    }
}