package com.gyf.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.gyf.dto.StartupRequest;
import com.gyf.entity.Startup;
import com.gyf.service.StartupService;

@RestController
@RequestMapping("/api/startups")
public class StartupController {

    @Autowired
    private StartupService startupService;

    //Create Method
    @PostMapping
    public Startup createStartup(@RequestBody StartupRequest request) {

        return startupService.createStartup(request);
    }
    
    //ALL List
    @GetMapping
    public List<Startup> getAllStartups() {

        return startupService.getAllStartups();
    }
    
    //Get By ID
    @GetMapping("/{id}")
    public Startup getStartupById(
            @PathVariable Long id) {

        return startupService.getStartupById(id);
    }
    
    //Approval
    @PutMapping("/{id}/approve")
    public Startup approveStartup(@PathVariable Long id) {

        return startupService.approveStartup(id);
    }
    
    //Reject
    @PutMapping("/{id}/reject")
    public Startup rejectStartup(@PathVariable Long id) {

        return startupService.rejectStartup(id);
    }
    
    
}