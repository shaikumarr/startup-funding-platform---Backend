package com.gyf.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.gyf.entity.Startup;

public interface StartupRepository extends JpaRepository<Startup, Long> {

    long countByStatus(String status);

}