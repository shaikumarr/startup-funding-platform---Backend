package com.gyf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gyf.entity.InvestmentInterest;

public interface InvestmentInterestRepository
        extends JpaRepository<InvestmentInterest, Long> {

}