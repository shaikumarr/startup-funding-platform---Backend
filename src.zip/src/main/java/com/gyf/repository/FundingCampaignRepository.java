package com.gyf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gyf.entity.FundingCampaign;

public interface FundingCampaignRepository
        extends JpaRepository<FundingCampaign, Long> {

}