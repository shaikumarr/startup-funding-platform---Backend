package com.gyf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gyf.entity.Investor;

public interface InvestorRepository extends JpaRepository<Investor, Long> {
	long countByStatus(String status);

}