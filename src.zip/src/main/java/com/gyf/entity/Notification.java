package com.gyf.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.PrePersist;

@Entity
@Table(name = "notifications")
public class Notification {

	
	@PrePersist
	public void prePersist() {

	    if (createdDate == null) {
	        createdDate = LocalDateTime.now();
	    }

	    if (isRead == null) {
	        isRead = false;
	    }
	}
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;

    private String title;

    private String message;

    private Boolean isRead = false;

    private LocalDateTime createdDate;

    public Notification() {
    }

    public Notification(
            Long userId,
            String title,
            String message,
            Boolean isRead,
            LocalDateTime createdDate) {

        this.userId = userId;
        this.title = title;
        this.message = message;
        this.isRead = isRead;
        this.createdDate = createdDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Boolean getIsRead() {
        return isRead;
    }

    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(
            LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }
}